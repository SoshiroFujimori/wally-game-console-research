# Standalone texture-command handshake diagnostic

This folder is self-contained. It tests the official RasterIX `CommandParser` from revision `9269a01c9bd4c3342bfa70ef8e3cdd751c15c6d0` and a diagnostic candidate stored in a separate file. It does not modify the official submodule or the Wally game-console checkout.

## Run

Install Python 3, Verilator, a C++ compiler and make. This invocation was verified with Verilator 5.026:

```sh
python3 reproduce.py
```

The runner checks source hashes, compiles both versions, and saves new build/test logs under a timestamped directory. Its observed output is:

```text
original PARSER_SUMMARY cases=12 failures=6
candidate PARSER_SUMMARY cases=12 failures=0
EXPECTED_FAILURE_REPRODUCED .../result.json
```

The original test executable intentionally exits with status 1 when it detects the mismatch. The outer Python runner exits with status 0 only when the expected original failure and the twelve-case candidate result both reproduce. This is a successful reproduction of a defect, not a claim that the original parser passed.

## Stimulus and expected behavior

Each case sends one texture command followed by eight distinct 2048-byte page addresses, starting at `0x9e000000`. A source word stays VALID with the same data until a VALID-and-READY handshake. The source gap after an accepted word is 0, 5, 20 or 100 cycles. The texture receiver inserts a delay of 0, 100 or 500 cycles after accepting an address. The test independently checks every accepted output address and the final-word indication.

For a source gap of 5 and a receiver delay of 100, the original parser outputs page indices `0,1,1,2,2,3,4,5` instead of `0,1,2,3,4,5,6,7`. Only combinations with both source gaps and receiver stalls fail in this twelve-case set. No CPU, APB bus, clock crossing, command FIFO, DDR controller, or texture sampler is needed to reproduce this behavior.

## Candidate and limits

`candidate-fix.patch` adds input-handshake guards before accepting a source word or advancing the source stream. It is saved only to test the suspected mechanism. Passing these twelve deterministic cases is not an exhaustive correctness proof. This candidate has not been tested on the FPGA, adopted into the product, or submitted upstream.

The parser file is byte-identical to the prior pinned RasterIX revision `9fdcf97a31b2e4247594e06d605871980cd5e9e1`; this statement concerns the parser source itself. The real-board large-texture observations are recorded separately in the parent experiment. They are consistent with the standalone result, but no patched/unpatched board A/B test has established that every observed board pixel mismatch has the same cause.

`manifest.json` records the copied source hashes. The upstream copyright and license notices are retained in the source files and `LICENSE`.
