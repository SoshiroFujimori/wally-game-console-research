#!/usr/bin/env python3
"""Reproduce sparse-source texture-page duplication without an FPGA."""
from pathlib import Path
import argparse,datetime,hashlib,json,re,shutil,subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--verilator',default=shutil.which('verilator'))
p.add_argument('--output',type=Path)
a=p.parse_args();root=Path(__file__).resolve().parent
assert a.verilator,'Install Verilator, a C++ compiler and make first'
manifest=json.loads((root/'manifest.json').read_text())
for name,sha in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=(a.output or root/('run-'+stamp)).resolve();out.mkdir(exist_ok=False)
version=subprocess.check_output([a.verilator,'--version'],text=True).strip()
results=[]
for label,filename,expected_exit,expected_failures in (
    ('original','CommandParser-original.v',1,6),
    ('candidate','CommandParser-candidate.v',0,0)):
    obj=out/label
    command=[a.verilator,'--cc','--exe','--build','-j','2','-Wno-fatal','--top-module','CommandParser','-I'+str(root),'--Mdir',str(obj),'-o','parser_test',str(root/filename),str(root/'test-command-parser.cpp')]
    with (out/(label+'-build.log')).open('w') as f:
        build=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
    assert build.returncode==0,'Build failed: '+str(out/(label+'-build.log'))
    run=subprocess.run([str(obj/'parser_test')],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (out/(label+'-test.log')).write_text(run.stdout)
    summary=re.search(r'PARSER_SUMMARY cases=(\d+) failures=(\d+)',run.stdout)
    assert summary and int(summary[1])==12 and int(summary[2])==expected_failures and run.returncode==expected_exit,run.stdout
    row={'variant':label,'exit':run.returncode,'cases':int(summary[1]),'failures':int(summary[2]),'command':command,'sha256':hashlib.sha256((root/filename).read_bytes()).hexdigest()}
    results.append(row);print(label,summary[0],flush=True)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verilator':version,'expected_failure_reproduced':True,'results':results,'limits':'Twelve deterministic texture-command cases only. The candidate has not been validated on a board or as a general upstream repair.'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print('EXPECTED_FAILURE_REPRODUCED',str(out/'result.json'),flush=True)
